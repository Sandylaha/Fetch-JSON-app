package com.example.pascolanapp.network;

import com.example.pascolanapp.model.Types;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface APIInterface {
    @GET("android/v1/prod/Category/hi/category.json")
    Call<List<Types>> getTypes();

    }
