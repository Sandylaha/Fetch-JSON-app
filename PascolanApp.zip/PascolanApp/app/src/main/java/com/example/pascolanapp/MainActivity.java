package com.example.pascolanapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.pascolanapp.model.Types;
import com.example.pascolanapp.network.APIClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    GridView gridView;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView=findViewById(R.id.gridView);
        Call<List<Types>> call= APIClient.apiInterface().getTypes();
        call.enqueue(new Callback<List<Types>>() {
            @Override
            public void onResponse(Call<List<Types>> call, Response<List<Types>> response) {
                if (response.isSuccessful()) {
                    customAdapter = new CustomAdapter(response.body(), MainActivity.this);
                    gridView.setAdapter(customAdapter);
                } else {
                    Toast.makeText(getApplicationContext(), "An error occurred", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Types>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "An error occurred"+t.getLocalizedMessage(), Toast.LENGTH_LONG).show();

            }
        });


    }

    public class CustomAdapter extends BaseAdapter{
        public List<Types> typesList;
        public Context context;

        public CustomAdapter(List<Types> typesList,Context context){
            this.typesList=typesList;
            this.context=context;
        }


        @Override
        public int getCount() {
            return typesList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view= LayoutInflater.from(context).inflate(R.layout.new_file,null);
            TextView name=view.findViewById(R.id.textView);
            ImageView image=view.findViewById(R.id.imageView);
            name.setText(typesList.get(position).getN());
            Glide.with(context).load(typesList.get(position).getP()).into(image);
            return view;
        }

    }
    public void openNewActivity(View view){
        Intent intent = new Intent (this, Main2Activity.class);
        startActivity(intent);
    }
}
